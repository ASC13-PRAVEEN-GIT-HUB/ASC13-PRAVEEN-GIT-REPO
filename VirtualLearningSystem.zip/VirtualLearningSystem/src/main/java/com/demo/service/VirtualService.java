package com.demo.service;

import com.demo.entity.VirtualEntity;
import java.util.List;

public interface VirtualService {
    List<VirtualEntity> getAllCourse();

    VirtualEntity getCourseById(Long id);

    List<VirtualEntity> getCoursesByCourseAuthor(String author);

    VirtualEntity addCourse(VirtualEntity course);

    void deleteCourse(Long id);

    VirtualEntity updateCourseById(Long id, VirtualEntity existingCourse);
}
