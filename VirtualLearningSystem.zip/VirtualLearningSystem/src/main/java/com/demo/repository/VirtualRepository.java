package com.demo.repository;

import com.demo.entity.VirtualEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface VirtualRepository extends JpaRepository<VirtualEntity, Long> {
    List<VirtualEntity> findByCourseAuthor(String courseAuthor);
}
